<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'إعدادات المطورين';

// Text
$_['text_success']     = 'تم تعديل الاعدادات بنجاح !';
$_['text_theme']       = 'القالب';
$_['text_sass']        = 'SASS';
$_['text_cache']       = 'تم مسح الملفات المؤقتة - الكاش لـ %s !';

// Column
$_['column_component'] = 'العنصر';
$_['column_action']    = 'تحرير';

// Entry
$_['entry_theme']      = 'القالب';
$_['entry_sass']       = 'SASS';
$_['entry_cache']      = 'الملفات المؤقتة - الكاش';

// Button
$_['button_on']        = 'تشغيل';
$_['button_off']       = 'إيقاف';

// Error
$_['error_permission'] = 'تحذير : أنت لاتمتلك صلاحيات التعديل !';
