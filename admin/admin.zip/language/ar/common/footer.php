<?php

// Text
$_['text_footer'] = '<b>OTG</b> &copy;' . date( 'Y' ) . ' جميع الحقوق محفوظة';
//$_['text_version'] 	 = 'الاصدار رقم %s';